<?php
class Admin_model extends CI_Model{

	public function post()
    {
    	$request = $_POST;
        
        $insert_data = array('title' => $request['title']);

        if($request['start_date'] > $request['end_date']){
        	$this->session->set_flashdata('error', 'End date should be greater or equel to start date');
        	return FALSE;
        }else{

        	$insert_data['start_date'] = $request['start_date'];
        	$insert_data['end_date'] = $request['end_date'];
        	$insert_data['repeat_type'] = $request['repeat_type'];
        	$insert_data['every'] = $request['every'];
        	$insert_data['every_type'] = $request['every_type'];
        	$insert_data['every_on'] = $request['every_on'];
        	$insert_data['day_name'] = $request['day_name'];
        	$insert_data['month_year'] = $request['month_year'];

        	$this->db->insert('event', $insert_data);
        	$this->session->set_flashdata('success', 'Event added successfully');
        	return TRUE;

        }
    }

    public function put($id)
    {
        $request = $_POST;
        
        $update_data = array('title' => $request['title']);

        if($request['start_date'] > $request['end_date']){
            $this->session->set_flashdata('error', 'End date should be greater or equel to start date');
            return FALSE;
        }else{

            $update_data['start_date'] = $request['start_date'];
            $update_data['end_date'] = $request['end_date'];
            $update_data['repeat_type'] = $request['repeat_type'];
            $update_data['every'] = $request['every'];
            $update_data['every_type'] = $request['every_type'];
            $update_data['every_on'] = $request['every_on'];
            $update_data['day_name'] = $request['day_name'];
            $update_data['month_year'] = $request['month_year'];

            $this->db->where('id', $id);
            $this->db->update('event', $update_data);
            $this->session->set_flashdata('success', 'Event updated successfully');
            return TRUE;

        }
    }

    public function get_event($id){
        $result = array();

        $this->db->from('event');
        $this->db->where('id',$id);
        $query = $this->db->get();
        if($query->num_rows() > 0){
            $result = $query->row_array();
        }
        return $result;
    }

    public function get_event_view($id){
        $result = array();

        $this->db->from('event');
        $this->db->where('id',$id);
        $query = $this->db->get();
        if($query->num_rows() > 0){
            $result = $query->row_array();
            $result['dates'] = array();

            if($result['repeat_type'] == '1'){

                if($result['every'] == 'Every'){

                    if($result['every_type'] == 'Day'){
                        // Get List of Every day

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P1D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Week'){
                        // Get List of Every week

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P7D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }


                    }else if($result['every_type'] == 'Month'){
                        // Get List of Every month

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P1M'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Year'){
                        // Get List of Every year

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P1Y'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }
                }else if($result['every'] == 'Every Other'){

                    if($result['every_type'] == 'Day'){
                        // Get List of Every second day

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P2D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Week'){
                        // Get List of Every second week

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P14D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }


                    }else if($result['every_type'] == 'Month'){
                        // Get List of Every second month

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P2M'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Year'){
                        // Get List of Every second year

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P2Y'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }
                }else if($result['every'] == 'Every Third'){

                    if($result['every_type'] == 'Day'){
                        // Get List of Every second day

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P3D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Week'){
                        // Get List of Every second week

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P21D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }


                    }else if($result['every_type'] == 'Month'){
                        // Get List of Every second month

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P3M'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Year'){
                        // Get List of Every second year

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P3Y'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }
                }else if($result['every'] == 'Every Fourth'){

                    if($result['every_type'] == 'Day'){
                        // Get List of Every second day

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P4D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Week'){
                        // Get List of Every second week

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P28D'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }


                    }else if($result['every_type'] == 'Month'){
                        // Get List of Every second month

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P4M'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }else if($result['every_type'] == 'Year'){
                        // Get List of Every second year

                        $period = new DatePeriod(
                             new DateTime($result['start_date']),
                             new DateInterval('P4Y'),
                             new DateTime($result['end_date'])
                        );

                        foreach ($period as $key => $value) {
                            $date = $value->format('Y-m-d');  
                            $day = $value->format('D');  
                            $result['dates'][] = array('date' => $date, 'day' => $day);
                        }

                    }
                }

            }else{
                // 
                $start_obj = DateTime::createFromFormat('Y-m-d', $result['start_date']);
                $new_date = DateTime::createFromFormat('Y-m-d', $result['start_date']);
                $end_obj = DateTime::createFromFormat('Y-m-d', $result['end_date']);

                if($result['month_year'] == 'Month'){
                    $result['month_year'] = 'this month';
                }
                if($result['month_year'] == 'Year'){
                    $result['month_year'] = $start_obj->format('Y');
                }

                while($end_obj >= $start_obj){

                    $start_obj = $start_obj->modify($result['every_on']." ".$result['day_name']." of ".$result['month_year']);
                    // $start_obj = $new_date;
                    $date = $start_obj->format('Y-m-d');  
                    $day = $start_obj->format('D');  
                    $result['dates'][] = array('date' => $date, 'day' => $day);

                   

                }
                
                
                
            }
            
        }
        return $result;
    }
        
    

}
?>