<style type="text/css">
    .parsley-errors-list.filled{
        list-style-type: none;
        color: #B94A48;
        padding-left: 0;
    }
    .parsley-errors-list.filled li{
        list-style-type: none;
        color: red;
        font-size: 14px;
    }
    
</style>
<div class="content">
    <div class="container-fluid">

        <div class="row mb-1">
            <div class="col-sm-12 mt-3">
                <div class="page-title-box">
                    <h4 class="page-title">Admin Event Manage</h4>
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('/'); ?>">Back to Admin Dashbaord</a></li>
                    </ol>
                </div>
            </div>
        </div>

        <?php
        $this->load->view('admin/includes/message');
        ?>

        <div class="row mt-4">

            <div class="col-xl-12">
                <div class="card m-b-20">
                    <div class="card-body">
                        <h4 class="mt-0 m-b-30 header-title">Add Event</h4>
                        <hr>
                        <form data-validate="parsley" method="post" action="<?php echo base_url('add'); ?>">
                            <div class="form-group">Title</label>
                                <?php
                                if((set_value('title') != NULL)){
                                    $field_value = set_value('title');
                                }else{
                                    $field_value = NULL;
                                }
                                
                                ?>
                                <input type="text" name="title" class="form-control" id="title" placeholder="Ex. Flower Show" required value="<?php echo $field_value; ?>">
                              </div>
                            <div class="form-group">Start Date</label>
                                <?php
                                $field_value = set_value('start_date');
                                ?>
                                <input type="text" name="start_date" class="form-control datepicker" id="start_date" placeholder="Year-Month-Date" readonly required>
                            </div>
                            <div class="form-group">To Date</label>
                                <?php
                                $field_value = set_value('end_date');
                                ?>
                                <input type="text" name="end_date" class="form-control datepicker" id="end_date" placeholder="Year-Month-Date" readonly required>
                            </div>
                            <div class="form-check">
                                <?php
                                $field_value = set_value('repeat_type');
                                if(!isset($field_value)){
                                    $field_value = '1';
                                }
                                ?>
                                <input class="form-check-input" type="radio" name="repeat_type" id="flexRadioDefault1" value="1" <?php echo ($field_value == '1')?'checked':''; ?> >
                                <label class="form-check-label" for="flexRadioDefault1">
                                    Repeat
                                </label>
                                  
                            </div>

                            <div class="col-md-12 row mt-2">

                                <div class="form-group col-6">
                                    <!-- <label for="exampleFormControlSelect1">Every</label> -->
                                    <select class="form-control" id="every" name="every">
                                      <option>Every</option>
                                      <option>Every Other</option>
                                      <option>Every Third</option>
                                      <option>Every Forth</option>
                                    </select>
                                </div>
                                <div class="form-group col-6">
                                    <!-- <label for="exampleFormControlSelect1">Every</label> -->
                                    <select class="form-control" id="every_type" name="every_type">
                                      <option>Day</option>
                                      <option>Week</option>
                                      <option>Month</option>
                                      <option>Year</option>
                                      
                                    </select>
                                </div>

                            </div>
                            

                            <hr>

                            <div class="form-check">
                                <?php
                                $field_value = set_value('repeat_type');
                                
                                ?>
                              <input class="form-check-input" type="radio" name="repeat_type" value="2" id="flexRadioDefault2" <?php echo ($field_value == '2')?'checked':''; ?>>
                              <label class="form-check-label" for="flexRadioDefault2">
                                Repeat on the
                              </label>
                            </div>

                            <div class="col-md-12 row mt-2">

                                <div class="form-group col-3">
                                    <!-- <label for="exampleFormControlSelect1">Every</label> -->
                                    <select class="form-control" id="every_on" name="every_on">
                                      <option>First</option>
                                      <option>Second</option>
                                      <option>Third</option>
                                      <option>Forth</option>
                                    </select>
                                </div>
                                <div class="form-group col-2">
                                    <!-- <label for="exampleFormControlSelect1">Every</label> -->
                                    <select class="form-control" id="day_name" name="day_name">
                                      <option>Sunday</option>
                                      <option>Monday</option>
                                      <option>Tuesday</option>
                                      <option>Wednesday</option>
                                      <option>Thursday</option>
                                      <option>Friday</option>
                                      <option>Saturday</option>
                                      
                                    </select>
                                </div>
                                <div class="form-group col-2 text-center">
                                    of the
                                </div>
                                <div class="form-group col-3">
                                    <!-- <label for="exampleFormControlSelect1">Every</label> -->
                                    <select class="form-control" id="month_year" name="month_year">
                                      <option>Month</option>
                                      <option>3 Month</option>
                                      <option>4 Month</option>
                                      <option>6 Month</option>
                                      <option>Year</option>
                                    </select>
                                </div>

                            </div>

                          <div class="form-group">
                            <button class="btn btn-primary" type="submit" name="submit">Save</button>
                          </div>
                         
                        </form>

                      <!--   <div class="table-responsive">
                            <table class="table table-vertical">

                                <tbody>
                                    <tr>
                                        <th>
                                            Profile
                                        </th>
                                        <th>
                                            First Name
                                        </th>
                                        <th>
                                            Last Name
                                        </th>
                                        <th>
                                            Email
                                        </th>
                                        <th>
                                            Phone Number
                                        </th>
                                        <th class="text-center">
                                            Action
                                        </th>
                                    </tr>
                                  
                                </tbody>
                            </table>
                        </div> -->
                    </div>
                </div>
            </div>


        </div>
        <div class="row">
        </div>

    </div>
</div>
<script type="text/javascript">
    $('.datepicker').datepicker({ format: 'yyyy-mm-dd', startDate: '-0m' });
    $('form').parsley();
</script>