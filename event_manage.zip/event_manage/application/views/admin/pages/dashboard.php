<div class="content">
    <div class="container-fluid">

        <div class="row mb-1">
            <div class="col-sm-12 mt-3">
                <div class="page-title-box">
                    <h4 class="page-title">Admin Event Manage</h4>
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript:void(0);">Welcome to Admin Dashbaord</a></li>
                    </ol>
                </div>
            </div>
        </div>

        <?php
        $this->load->view('admin/includes/message');
        ?>

        <div class="row mt-4">
            <div class="col-xl-12">
                <a href="<?php echo base_url('/add'); ?>" class='btn btn-primary btn-sm float-right mb-3'>+ ADD EVENT</a>
            </div>    
            
            <div class="col-xl-12">

                <div class="card m-b-20">
                    
                    <div class="card-body">

                        <h4 class="mt-0 m-b-30 header-title">List Of Events </h4>
                        
                        <hr>
                      
                        <?php echo $this->datatables->generate(); ?>
                    </div>
                </div>
            </div>


        </div>

    </div>
</div>

<?php
$this->load->view('admin/includes/datatable');
?>