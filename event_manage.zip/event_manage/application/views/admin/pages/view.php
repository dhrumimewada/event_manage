<div class="content">
    <div class="container-fluid">

        <div class="row mb-1">
            <div class="col-sm-12 mt-3">
                <div class="page-title-box">
                    <h4 class="page-title">Admin Event Manage</h4>
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="<?php echo base_url('/'); ?>">Welcome to Admin Dashbaord</a></li>
                    </ol>
                </div>
            </div>
        </div>


        <div class="row mt-4"> 
            
            <div class="col-xl-12">

                <div class="card m-b-20">
                    
                    <div class="card-body">

                        <h4 class="mt-0 m-b-30 header-title"><?php echo $title .' | '. $start_date.' To '.$end_date; ?></h4>
                        
                        <hr>
                        
                        <table class="table">
                            
                            <?php
                            if(isset($dates) && !empty($dates)){

                                foreach ($dates as $key => $value) {
                                    
                                    ?>
                                    <tbody>
                                      <tr>
                                        <td><?php echo $value['date']; ?></td>
                                        <td><?php echo $value['day']; ?></td>
                                        
                                      </tr>

                                     
                                    </tbody>
                                    <?php
                                }
                            }
                            ?>
                            
                        </table>

                    </div>
                </div>
            </div>


        </div>

    </div>
</div>
