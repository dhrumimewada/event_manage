<?php
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Admin | Event Manage">
        <meta name="keyword" content="Admin | Event Manage">
        <link rel="shortcut icon" href="">
        <title>Admin | Event Manage</title>
        
        <link rel="stylesheet" href="">

        <!-- DataTables -->
        <link href="<?php echo base_url('plugins/datatables/dataTables.bootstrap4.min.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('plugins/datatables/buttons.bootstrap4.min.css'); ?>" rel="stylesheet" type="text/css" />
        <!-- Responsive datatable examples -->
        <link href="<?php echo base_url('plugins/datatables/responsive.bootstrap4.min.css'); ?>" rel="stylesheet" type="text/css" />

        <!-- autoclose date picker -->
        <link href="<?php echo base_url('plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css'); ?>" rel="stylesheet">
        <link href="<?php echo base_url('plugins/select2/css/select2.min.css'); ?>" rel="stylesheet" type="text/css" />

        <link href="<?php echo assets('css/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo assets('css/metismenu.min.css'); ?>" rel="stylesheet" type="text/css">

        <link href="<?php echo base_url('plugins/notiflix/notiflix-2.1.2.css'); ?>" rel="stylesheet" type="text/css">


        
        <!-- js -->
        <!-- jQuery  -->
        <script src="<?php echo assets('js/jquery.min.js'); ?>"></script>

        <!-- Js form validations -->
        <script src="<?php echo assets('js/validation/jquery.validate.js'); ?>"></script>
        <script src="<?php echo assets('js/validation/jquery.validate.min.js'); ?>"></script>
        <script src="<?php echo assets('js/validation/additional-methods.js'); ?>"></script>
        <script src="<?php echo assets('js/validation/additional-methods.min.js'); ?>"></script>

        <script src="<?php echo assets('js/bootstrap.bundle.min.js'); ?>"></script>



        <!-- notiflix -->
        <script src="<?php echo base_url('plugins/notiflix/notiflix-2.1.2.js'); ?>"></script>

        <!-- parsleyjs -->
        <script src="<?php echo base_url('plugins/parsleyjs/parsley.min.js'); ?>"></script>
        
        <script src="<?php echo assets('/js/custom/admin/custom.js'); ?>"></script>
        

        <!-- Auto Close datepicker -->
        <script src="<?php echo base_url('plugins/bootstrap-datepicker/js/bootstrap-datepicker.js'); ?>"></script>


        <script type="text/javascript">
            var BASE_URL = '<?php echo base_url(); ?>';
            var prof_default = '';
        </script>
    </head>

    <body>

        <!-- Begin page -->
        <div id="wrapper">



            <div class="">

                