<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function post()
	{
		$this->load->model("admin_model");
		$this->load->library('form_validation');

		if(isset($_POST['submit'])){

			

			$this->form_validation->set_rules('title', 'title', 'trim|required');
            $this->form_validation->set_rules('start_date', 'start date', 'trim|required|callback_validate_date');
            $this->form_validation->set_rules('end_date', 'end date', 'trim|required|callback_validate_date');
            $this->form_validation->set_rules('repeat_type', 'repeat type', 'required');

            if ($this->form_validation->run() == FALSE)
            {

            	
              	$error = validation_errors();
              	$error = strip_tags($error);
              	$this->session->set_flashdata('error', $error);

              
            }
            else
            {
                $result = $this->admin_model->post();
                if($result == TRUE){
                	redirect('/');
                }
                
            }

		}


		// $this->db->from('event');
		// $query = $this->db->get();
		// if($query->num_rows() > 0){
		// 	$result_data = $query->result_array();
		// }
    	

		$this->render('post');
	}

	public function index()
	{
		
		$this->load->library('Datatables');
		$dt_data = new Datatables;
		$dt_data->select('event.*', false)->from('event')->where('event.deleted_at', NULL);
		$action['edit'] = base_url('edit/');
		$action['view'] = base_url('view/');
		$dt_data->style(array(
				'class' => 'table table-hover dt-responsive nowrap',
				'style' => 'border-collapse: collapse; border-spacing: 0; width: 100%;'
			))
			->column('Id', 'id')
			->column('Title', 'title',function($title,$row){
				 $out = strlen($title) > 50 ? substr($title,0,50)."..." : $title;
				 return $out;

			})
			->column('Recurrence', 'repeat_type',function($repeat_type,$row){
				 if($repeat_type == '1'){
				 	return $row['every'].' '.$row['every_type'];
				 }else{
				 	return 'Every '.$row['every_on'].' '.$row['day_name'].' of the '.$row['month_year'];
				 }
			})
			->column('Start Date', 'start_date')
			->column('End Date', 'end_date')
			
			->column('Action', 'id', function ($id, $row) use ($action){
				$option = "";
				$option .= '<a href="' . $action['view'] . $id . '" class="btn btn-warning btn-sm waves-effect waves-light mr-1">View</a>';
				$option .= '<a href="' . $action['edit'] . $id . '" class="btn btn-primary btn-sm waves-effect waves-light">Edit</a>';
				$option .= " <button type='button' data-table='event' data-id='".$row['id']."' class='btn btn-danger btn-sm waves-effect waves-light delete' title='Delete' data-popup='tooltip' onclick='delete_notiflix(this);'>Delete</button>";
				return $option;
			});

		$dt_data->searchable('id,title');
		$dt_data->datatable('event');
		$dt_data->init();
		$data['datatable'] = true;

		$data['add_url'] = base_url('/add');
        
		$this->render('dashboard', $data);
	}


	public function put($id)
	{
		$this->load->model("admin_model");
		$this->load->library('form_validation');

		if(isset($_POST['submit'])){

			

			$this->form_validation->set_rules('title', 'title', 'trim|required');
            $this->form_validation->set_rules('start_date', 'start date', 'trim|required|callback_validate_date');
            $this->form_validation->set_rules('end_date', 'end date', 'trim|required|callback_validate_date');
            $this->form_validation->set_rules('repeat_type', 'repeat type', 'required');

            if ($this->form_validation->run() == FALSE)
            {

            	
              	$error = validation_errors();
              	$error = strip_tags($error);
              	$this->session->set_flashdata('error', $error);

              
            }
            else
            {
                $result = $this->admin_model->put($id);
                if($result == TRUE){
                	redirect('/');
                }
                
            }

		}


		$data = $this->admin_model->get_event($id);

		// echo "<pre>";
		// print_r($data);
		// exit;
    	

		$this->render('edit', $data);
	}

	public function view($id)
	{
		$this->load->model("admin_model");
		$this->load->library('form_validation');
		$data = $this->admin_model->get_event_view($id);

		// echo "<pre>";
		// print_r($data);
		// exit;

    	

		$this->render('view', $data);
	}

	public function validate_date($value)
	{
		if (preg_match("/^[0-9]{4}-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/",$value)) {
		    return true;
		} else {
			$this->form_validation->set_message('validate_date', 'The {field} field is invalid date');
		    return false;
		}
	}

	public function validate_to($to_date, $from_date)
	{
		$from = new DateTime($from_date);
		$to = new DateTime($to_date);

		if($to < $from){
			$this->form_validation->set_message('validate_to', 'The {field} field should be greater than start date');
		    return false;
		}

	}

	public function delete(){
		$update = array('deleted_at' => date('Y-m-d H:i:s'));
		$this->db->where('id', $_POST['id']);
		$this->db->update($_POST['table'], $update);
	}
}
