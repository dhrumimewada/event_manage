

function delete_notiflix(e)
{

  var tr = $(e).parent().closest('tr');
  var table = $(e).data('table');
  var id = $(e).data('id');

  Notiflix.Confirm.Show(
    'Confirm',
    'Are you sure that you want to delete this record?',
    'Yes',
    'No',
    function(){
      Notiflix.Loading.Standard();
      $.ajax({
        url: BASE_URL+'Welcome/delete',
        type: "POST",
        data:{
          table:table,
          id:id
        },
        success: function (returnData) {
            Notiflix.Loading.Remove();
            Notiflix.Notify.Success('Deleted');
            tr.remove();
        }
      }); 
  });

}

function remove_row(this_element) {
   if (this_element.closest("tr").hasClass("child")){
    //console.log("in");
        this_element.closest("tr").prev("tr").slideUp(300, function () {
            this_element.closest("tr").prev("tr").remove();
            this_element.closest("tr").remove();
        });
    }else{
        //console.log("innn");
        this_element.closest("tr").slideUp(300, function () {
            this_element.closest("tr").remove();
        });
    }
    return true;
}